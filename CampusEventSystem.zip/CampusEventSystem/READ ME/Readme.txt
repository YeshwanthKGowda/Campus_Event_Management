My Understanding of this project

This is a basic event reporting system for a campus event management platform and also helps add new events as an organiser or help the students to register for an event. It also has track of the attendance and feedback mechanism which helps the organiser improvise the event based on the students feedback and also helps the student to pick their interests of events. 

The main idea is 

--> College staff (admins) can create events 
--> Students to register for events, attend them and give feedback
--> By tracking the students feedback and attendance we have created a system which creates a report such as event popularity, student participation, and feedback ratings

The features I have implemented are 
--> event creation and student registration
--> Attendance marking 
--> feedback collection 
--> reports such as 
			-> total registrations 
			-> Attendance percentage
			-> Average feedback
			-> Student participation report 
			-> Event Popularity 
			-> (Bonus) Top 3 most active students

Assumptions I made 

-->Each college have multiple hackathons, but event IDs are unique only inside a college 
--> A student can register for multiple events but only once per event 
--> If a student registers but does not attend, their attendance for the event is marked as absent
--> Feedback is optional, Only students who attended can give feedback. 
--> canceled events will not appear in reports.

Tech stack I used 
--> Language - PYTHON
--> Framework - Flask 
--> Database - SQLite 

AI used are 
--> Chat GPT
--> deepseek


